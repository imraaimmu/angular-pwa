import { Component, OnInit } from '@angular/core';
import { SwUpdate } from '@angular/service-worker';
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas"

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
// Default export is a4 paper, portrait, using millimeters for units
export class AppComponent  implements OnInit {
  doc = new jsPDF('p', 'mm', 'a4');
  // {
  //   orientation: "landscape",
  //   unit: "in",
  //   format: [4, 2]
  // }
  title = 'angular-pwa-app';
  constructor(private swUpdate: SwUpdate) {
  }

  posts = [

    {

      id: 1,

      title: 'Angular Http Post Request Example'

    },

    {

      id: 2,

      title: 'Angular 10 Routing and Nested Routing Tutorial With Example'

    },

    {

      id: 3,

      title: 'How to Create Custom Validators in Angular 10?'

    },

    {

      id: 4,

      title: 'How to Create New Component in Angular 10?'

    }

  ];

  callFunction(event, post){

    console.log(post);

  }

   
  reader: ReadableStreamDefaultReader;
  writer: WritableStreamDefaultWriter;
  encoder = new TextEncoder();
  decoder = new TextDecoder();
  showError = true;
  errorMessage = "";
async  connect() {
  this.showError = false;
   if ('serial' in navigator) {
      try {
        const port = await (navigator as any).serial.requestPort();
        await port.open({ baudrate: 9600 });
        this.reader = port.readable.getReader();
        this.writer = port.writable.getWriter();
        let signals = await port.getSignals();
        console.log(signals)
      } catch(err) {
        this.errorMessage = 'There was an error opening the serial port:'+ err;
        this.showError = true;
      }
    } else {
      this.errorMessage = "check console log";
      this.showError = true;
      console.error('Web serial doesn\'t seem to be enabled in your browser. Try enabling it by visiting:')
      console.error('chrome://flags/#enable-experimental-web-platform-features');
      console.error('opera://flags/#enable-experimental-web-platform-features');
      console.error('edge://flags/#enable-experimental-web-platform-features');
    }

  }
  async sendData(data: string) {
    this.showError = false;
    console.log("sending : "+data);
    if(this.writer){
      const dataArrayBuffer = this.encoder.encode(data);
      return await this.writer.write(dataArrayBuffer);
    }else{
      this.errorMessage = "Connect to device via serial port to send data";
      this.showError = true;
    }
  }

  async getData(): Promise<string> {
    try {
      this.showError = false;
      if(this.reader){
        const readerData = await this.reader.read();
        return this.decoder.decode(readerData.value);
      }else{
        this.errorMessage ="Connect to device via serial port to receive data";
        this.showError = true;
      }
    } catch (err) {
      this.errorMessage = `error reading data: ${err}`;
      this.showError = true;
      console.error(this.errorMessage);
      return this.errorMessage;
    }
  }
  savePDF(){
    var data = document.getElementById('badge');
    html2canvas(data).then(canvas => {
    // Few necessary setting options
    var imgWidth = 208;
    var pageHeight = 295;
    var imgHeight = canvas.height * imgWidth / canvas.width;
    var heightLeft = imgHeight;
    
    const contentDataURL = canvas.toDataURL('image/png')
    var position = 0;
    this.doc.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)
    this.doc.save('Badge.pdf'); // Generated PDF
    });
  }
  ngOnInit() {
      if (this.swUpdate.isEnabled) {
          this.swUpdate.available.subscribe(() => {

              if(confirm("New version available. Load New Version?")) {
                console.log("Enabled 1")
                  window.location.reload();
              }
          });
      }        
  }
  k(){
    var user = prompt ("U name:");
    var people = document.getElementById("name");
    people.innerHTML = user;
    
    var mob = prompt ("mobile no.");
    var phone = document.getElementById ("phn");
    phone.innerHTML = mob;
    
    var mail1 = prompt ("Email");
    var mail = document.getElementById ("mailadd");
    mail.innerHTML = mail1;
}
}
